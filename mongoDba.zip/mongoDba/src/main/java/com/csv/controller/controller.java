package com.csv.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.csv.entity.students;
import com.csv.respository.respo;
import com.csv.service.serve;

@RestController
@RequestMapping("/")
public class controller {
	@Autowired
	respo respo;

	@Autowired
	serve serve;

	@PostMapping("/insert")
	public students ins(@RequestBody students students) {

		return respo.save(students);
	}

	@GetMapping("/getall")
	public List<students> alldata() {

		return respo.findAll();
	}

	@GetMapping("/search/{dish}")
	public List<students> search(@PathVariable String dish) {

		return (List<students>) serve.finddata(dish);
	}

}
