package com.csv.respository;


import org.springframework.data.mongodb.repository.MongoRepository;

import com.csv.entity.students;

public interface respo extends MongoRepository<students, Integer>{

}
