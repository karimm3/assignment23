package com.csv.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.csv.entity.students;
import com.csv.respository.respo;

@Service
public class serve {

	@Autowired
	private respo respo;

	public List<students> finddata(String dish) {
		// TODO Auto-generated method stub
		List<students> li = new ArrayList<students>();

		List<students> s = respo.findAll();

		String[] parts = dish.split("\\s+");

		for (String part : parts) {

			for (students st : s) {

				String s1 = st.getDish();

				if (s1.contains(part)) {
					li.add(st);
				}
			}
		}

		return li;
	}

}
